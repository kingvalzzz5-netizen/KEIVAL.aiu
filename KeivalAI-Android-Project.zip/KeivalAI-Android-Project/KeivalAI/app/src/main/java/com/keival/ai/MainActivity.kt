package com.keival.ai

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {
        private val prefs = getSharedPreferences("keival", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun getKey(): String = prefs.getString("key", "") ?: ""

        @JavascriptInterface
        fun setKey(key: String) {
            prefs.edit().putString("key", key.trim()).apply()
        }

        @JavascriptInterface
        fun ask(id: Int, messagesJson: String) {
            Thread {
                var text = ""
                var err = ""
                try {
                    val key = getKey()
                    if (key.isEmpty()) throw Exception("API key belum diisi. Ketuk ikon ⚙ untuk mengisinya.")
                    val body = JSONObject()
                        .put("model", MODEL)
                        .put("max_tokens", 1024)
                        .put("system", SYSTEM_PROMPT)
                        .put("messages", JSONArray(messagesJson))
                    val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 20000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    conn.setRequestProperty("content-type", "application/json")
                    conn.setRequestProperty("x-api-key", key)
                    conn.setRequestProperty("anthropic-version", "2023-06-01")
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val raw = stream.bufferedReader().use { it.readText() }
                    val json = JSONObject(raw)
                    if (code in 200..299) {
                        val content = json.getJSONArray("content")
                        val sb = StringBuilder()
                        for (i in 0 until content.length()) {
                            val block = content.getJSONObject(i)
                            if (block.optString("type") == "text") sb.append(block.getString("text"))
                        }
                        text = sb.toString()
                    } else {
                        err = json.optJSONObject("error")?.optString("message") ?: "Error $code"
                    }
                } catch (e: Exception) {
                    err = e.message ?: "Terjadi kesalahan jaringan."
                }
                runOnUiThread {
                    web.evaluateJavascript(
                        "onAnswer($id,${JSONObject.quote(text)},${JSONObject.quote(err)})", null
                    )
                }
            }.start()
        }
    }

    companion object {
        const val MODEL = "claude-sonnet-5-5"
        const val SYSTEM_PROMPT =
            "Kamu adalah KEIVAL AI, asisten AI yang ramah dan membantu menjawab pertanyaan tentang apa saja. " +
            "Jawab dalam bahasa yang dipakai pengguna (default bahasa Indonesia), singkat, jelas, dan akurat. " +
            "Jika tidak yakin, katakan terus terang."
    }
}
